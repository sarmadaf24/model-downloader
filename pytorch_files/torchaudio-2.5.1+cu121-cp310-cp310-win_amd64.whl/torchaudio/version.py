__version__ = '2.5.1+cu121'
git_version = '1661daf10599ca8889f092ec37814fabbe202bb0'
